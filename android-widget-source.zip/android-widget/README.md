# SoraFit Android ホーム画面ウィジェット

Android 8以降向けのSoraFitウィジェットです。既存のWeb版/PWAとは別の小さなAndroidアプリとしてインストールします。

| 表示サイズの目安 | 内容 |
| --- | --- |
| 2×1 | 地域、現在の天気と気温、今日の降水確率 |
| 4×2 | 上記と最高・最低気温、Yahoo!天気の雨雲レーダーへのボタン |
| 4×3 | 上記と明日の予報、更新時刻、手動更新ボタン |

Androidのホーム画面は端末やランチャーによりマス目の寸法が異なります。ウィジェットを長押ししてサイズ変更すると、幅と高さに応じて3種類の表示に自動で切り替わります。

## ビルドと追加

1. GitHubの **Actions → Android widget APK** の成功した実行から `SoraFit-widget-debug-apk` をダウンロードして解凍します。中の `app-debug.apk` がインストール用ファイルです。このデバッグ版は個人利用・動作確認用です。
2. Android端末でAPKをインストールします。端末側で求められた場合だけ、このAPKを開くアプリに一時的にインストール許可を与えます。
3. ホーム画面を長押し → **ウィジェット** → **SoraFit ウィジェット** を追加します。
4. 市町村名を検索して候補を選びます。現在地の自動追跡は行いません。地域を変えるときは「SoraFit ウィジェット」アプリを開いて検索します。

表示はOpen-Meteoのモデル予報を約30分ごとに更新します。Androidの省電力制御などにより更新時刻が遅れることがあります。通信に失敗した場合は前回の予報を明示して表示します。ウィジェットの本体部分を押すと公開中のSoraFitが開きます。雨雲ボタンは設定地点のYahoo!天気レーダーを開きます。

Web版で選択した地域はAndroidアプリと自動同期しません。初回の地域選択とアプリ側の招待コード入力は別々です。位置情報権限やバックグラウンド位置取得は使用しません。

## 開発

GitHubの `android-widget-source.zip` を解凍し、その中の `android-widget` フォルダをAndroid Studioで開きます。Android SDKとJDK 17がある環境ではGradle 8.9を使い `gradle :app:assembleDebug` を実行できます。Android Gradle Plugin 8.7.3、compileSdk 35です。GitHub Actionsのビルド定義は `.github/workflows/android-widget.yml` です。
