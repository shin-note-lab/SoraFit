package jp.shinnote.sorafit.widget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final String TAG = "SoraFitWidget";
    private int widgetId;
    private LinearLayout results;
    private TextView message;
    private Button search;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        widgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(19, 39, 64));
        TextView title = label("SoraFit ウィジェット", 24, Color.WHITE);
        root.addView(title);
        TextView note = label("表示する市町村を検索して選んでください。追加後は長押しでサイズを変えられます。", 14, 0xffc6d8ec);
        note.setPadding(0, dp(10), 0, dp(16));
        root.addView(note);
        EditText city = new EditText(this);
        city.setSingleLine(true);
        city.setHint("例：南相馬市");
        city.setText("南相馬市");
        city.setTextColor(Color.WHITE);
        city.setHintTextColor(0xffa9bbcc);
        root.addView(city);
        search = new Button(this);
        search.setText("地域を検索");
        root.addView(search);
        message = label("Open-Meteo の予報を30分ごとに更新します。", 13, 0xffc6d8ec);
        message.setPadding(0, dp(12), 0, dp(6));
        root.addView(message);
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);
        setContentView(root);
        search.setOnClickListener(v -> searchCity(city.getText().toString().trim()));
    }

    private void searchCity(String query) {
        if (query.length() < 2) { message.setText("市町村名を2文字以上入力してください。"); return; }
        search.setEnabled(false);
        results.removeAllViews();
        message.setText("検索中…");
        new Thread(() -> {
            try {
                String url = "https://geocoding-api.open-meteo.com/v1/search?name="
                        + URLEncoder.encode(query, StandardCharsets.UTF_8.name())
                        + "&count=5&language=ja&countryCode=JP&format=json";
                JSONArray places = new JSONObject(WeatherData.readJson(url)).optJSONArray("results");
                if ((places == null || places.length() == 0) && query.matches(".*[市区町村]$")) {
                    String shortQuery = query.substring(0, query.length() - 1);
                    String retry = "https://geocoding-api.open-meteo.com/v1/search?name="
                            + URLEncoder.encode(shortQuery, StandardCharsets.UTF_8.name())
                            + "&count=5&language=ja&countryCode=JP&format=json";
                    places = new JSONObject(WeatherData.readJson(retry)).optJSONArray("results");
                }
                JSONArray choices = places;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    search.setEnabled(true);
                    if (choices == null || choices.length() == 0) { message.setText("見つかりませんでした。市名を短くして検索してください。"); return; }
                    message.setText("表示したい地域を選択");
                    for (int i = 0; i < choices.length(); i++) {
                        JSONObject place = choices.optJSONObject(i);
                        if (place == null) continue;
                        String name = place.optString("name") + "・" + place.optString("admin1");
                        double lat = place.optDouble("latitude", Double.NaN);
                        double lon = place.optDouble("longitude", Double.NaN);
                        if (!Double.isFinite(lat) || !Double.isFinite(lon)) continue;
                        Button option = new Button(this);
                        option.setText(name);
                        option.setOnClickListener(v -> choose(name, lat, lon));
                        results.addView(option);
                    }
                });
            } catch (Exception error) {
                runOnUiThread(() -> { search.setEnabled(true); message.setText("通信できませんでした。接続を確認して再試行してください。"); });
            }
        }, "sorafit-geocode").start();
    }

    private void choose(String name, double lat, double lon) {
        int[] ids = widgetId == AppWidgetManager.INVALID_APPWIDGET_ID ? WeatherWidget.ids(this) : new int[]{widgetId};
        if (ids.length == 0) {
            message.setText("先にホーム画面へウィジェットを追加してください。");
            return;
        }
        SharedPreferences.Editor editor = WeatherWidget.prefs(this).edit();
        for (int id : ids) {
            editor.putString(id + ".name", name).putLong(id + ".lat", Double.doubleToLongBits(lat))
                    .putLong(id + ".lon", Double.doubleToLongBits(lon)).remove(id + ".weather");
        }
        editor.apply();
        search.setEnabled(false);
        results.removeAllViews();
        message.setText("予報を取得しています…");
        for (int id : ids) WeatherWidget.render(this, id, false);
        new Thread(() -> {
            boolean success = false;
            String forecast = null;
            try {
                JSONObject json = new JSONObject(WeatherData.readJson(WeatherData.forecastUrl(lat, lon)));
                json.put("_fetchedAt", System.currentTimeMillis());
                forecast = json.toString();
                success = WeatherData.fromJson(forecast) != null;
            } catch (Exception error) {
                Log.w(TAG, "Initial forecast failed", error);
            }
            SharedPreferences.Editor update = WeatherWidget.prefs(getApplicationContext()).edit();
            for (int id : ids) {
                if (success) update.putString(id + ".weather", forecast);
                else update.remove(id + ".weather");
            }
            update.apply();
            boolean rendered = true;
            for (int id : ids) {
                try { WeatherWidget.render(getApplicationContext(), id, !success); }
                catch (RuntimeException error) {
                    rendered = false;
                    Log.w(TAG, "Widget update failed: " + id, error);
                }
                try { WeatherWidget.schedule(getApplicationContext(), id); }
                catch (RuntimeException error) { Log.w(TAG, "Scheduling failed: " + id, error); }
            }
            boolean loaded = success && rendered;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                search.setEnabled(true);
                if (loaded && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) finish();
                else message.setText(loaded ? "表示地域を更新しました。"
                        : "予報を表示できませんでした。通信を確認し、もう一度地域を検索してください。");
            });
        }, "sorafit-initial-forecast").start();
    }

    private TextView label(String text, int size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
