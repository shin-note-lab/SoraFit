package jp.shinnote.sorafit.widget;

import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import java.util.Locale;

public final class WeatherWidget extends AppWidgetProvider {
    static final String PREFS = "sorafit_widgets";
    private static final String REFRESH = "jp.shinnote.sorafit.widget.REFRESH";
    static SharedPreferences prefs(Context context) { return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static int[] ids(Context context) {
        return AppWidgetManager.getInstance(context).getAppWidgetIds(new ComponentName(context, WeatherWidget.class));
    }

    static void schedule(Context context, int id) {
        if (!contains(ids(context), id) || !prefs(context).contains(id + ".lat")) return;
        JobScheduler scheduler = context.getSystemService(JobScheduler.class);
        JobInfo job = new JobInfo.Builder(200_000 + id, new ComponentName(context, WeatherJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setOverrideDeadline(0).build();
        scheduler.schedule(job);
    }

    private static boolean contains(int[] ids, int id) {
        for (int candidate : ids) if (candidate == id) return true;
        return false;
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) { render(context, id, false); schedule(context, id); }
    }

    @Override public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int id, Bundle options) {
        render(context, id, false);
        schedule(context, id);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (REFRESH.equals(intent.getAction())) {
            int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
            schedule(context, id);
        }
    }

    @Override public void onDeleted(Context context, int[] appWidgetIds) {
        SharedPreferences.Editor editor = prefs(context).edit();
        JobScheduler scheduler = context.getSystemService(JobScheduler.class);
        for (int id : appWidgetIds) {
            editor.remove(id + ".name").remove(id + ".lat").remove(id + ".lon").remove(id + ".weather");
            scheduler.cancel(200_000 + id);
        }
        editor.apply();
    }

    static void render(Context context, int id, boolean failed) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        Bundle options = manager.getAppWidgetOptions(id);
        int width = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
        int height = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 120);
        int layout = width < 210 || height < 105 ? R.layout.widget_compact
                : height < 170 ? R.layout.widget_medium : R.layout.widget_large;
        RemoteViews views = new RemoteViews(context.getPackageName(), layout);
        SharedPreferences settings = prefs(context);
        boolean configured = settings.contains(id + ".lat");
        String name = settings.getString(id + ".name", "地点を設定");
        WeatherData data = WeatherData.fromJson(settings.getString(id + ".weather", null));
        views.setTextViewText(R.id.place, (failed && data != null ? "前回の予報 · " : "") + name);
        views.setTextViewText(R.id.now, !configured ? "タップして地域を選択" : data == null ? (failed ? "取得できません" : "取得中…")
                : data.icon + " " + data.temperature + "°  " + data.description);
        views.setTextViewText(R.id.rain, !configured ? "" : data == null ? "☂ —" : "☂ " + data.rain + "%");
        if (layout != R.layout.widget_compact) {
            views.setTextViewText(R.id.high_low, data == null ? "最高 — / 最低 —"
                    : "最高 " + data.high + "°  /  最低 " + data.low + "°");
            views.setOnClickPendingIntent(R.id.radar, open(context, id, radarUrl(settings, id), 1));
        }
        views.setOnClickPendingIntent(R.id.morning, configured ? morning(context, id) : configure(context, id));
        if (layout == R.layout.widget_large) {
            views.setTextViewText(R.id.tomorrow, data == null ? "明日 —"
                    : "明日 " + data.tomorrowIcon + "  " + data.tomorrowHigh + "° / " + data.tomorrowLow + "°  ☂ " + data.tomorrowRain + "%");
            views.setTextViewText(R.id.updated, data == null ? "Open-Meteo" : "Open-Meteo · " + data.updated + " 更新");
            Intent refresh = new Intent(context, WeatherWidget.class).setAction(REFRESH)
                    .setData(Uri.parse("sorafit-widget://refresh/" + id))
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
            views.setOnClickPendingIntent(R.id.refresh, PendingIntent.getBroadcast(context, id, refresh,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        }
        views.setOnClickPendingIntent(R.id.widget_root, configured
                ? open(context, id, "https://shin-note-lab.github.io/SoraFit/", 0)
                : configure(context, id));
        manager.updateAppWidget(id, views);
    }

    private static String radarUrl(SharedPreferences settings, int id) {
        if (!settings.contains(id + ".lat")) return "https://weather.yahoo.co.jp/weather/zoomradar/";
        return String.format(Locale.US, "https://weather.yahoo.co.jp/weather/zoomradar/?lat=%.6f&lon=%.6f&z=12",
                Double.longBitsToDouble(settings.getLong(id + ".lat", 0)),
                Double.longBitsToDouble(settings.getLong(id + ".lon", 0)));
    }

    private static PendingIntent open(Context context, int id, String url, int kind) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        return PendingIntent.getActivity(context, id * 3 + kind, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent configure(Context context, int id) {
        Intent intent = new Intent(context, MainActivity.class)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        return PendingIntent.getActivity(context, id * 3 + 2, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent morning(Context context, int id) {
        Intent intent = new Intent(context, MorningActivity.class)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        return PendingIntent.getActivity(context, id * 3 + 3, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
