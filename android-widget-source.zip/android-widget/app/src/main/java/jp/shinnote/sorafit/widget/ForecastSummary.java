package jp.shinnote.sorafit.widget;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.time.LocalDate;

/** Mirrors the day's analysis, text summary and spoken script in the SoraFit PWA. */
final class ForecastSummary {
    final String text;
    final String voice;

    private ForecastSummary(String text, String voice) {
        this.text = text;
        this.voice = voice;
    }

    static ForecastSummary fromJson(String saved, String place, boolean fromCache) throws Exception {
        JSONObject data = new JSONObject(saved);
        JSONObject current = data.getJSONObject("current");
        JSONObject daily = data.getJSONObject("daily");
        JSONObject hourly = data.getJSONObject("hourly");
        if (daily.getJSONArray("time").length() < 7) throw new IllegalArgumentException("Missing weekly forecast");
        JSONArray times = hourly.getJSONArray("time");
        String date = daily.getJSONArray("time").getString(0);
        String currentTime = current.getString("time");
        JSONArray feels = hourly.getJSONArray("apparent_temperature");
        JSONArray temperature = hourly.getJSONArray("temperature_2m");
        JSONArray wind = hourly.getJSONArray("wind_speed_10m");
        JSONArray gust = hourly.getJSONArray("wind_gusts_10m");
        JSONArray probability = hourly.getJSONArray("precipitation_probability");
        JSONArray precipitation = hourly.getJSONArray("precipitation");
        JSONArray codes = hourly.getJSONArray("weather_code");

        List<Integer> today = new ArrayList<>(), outing = new ArrayList<>(), outingRain = new ArrayList<>();
        for (int i = 0; i < times.length(); i++) {
            if (!times.getString(i).startsWith(date)) continue;
            today.add(i);
            int hour = hour(times.getString(i));
            if (hour >= 7 && hour <= 19) outing.add(i);
            // Hourly precipitation is the total for the hour ending at this timestamp.
            if (hour >= 8 && hour <= 19) outingRain.add(i);
        }
        if (today.isEmpty()) throw new IllegalArgumentException("Missing hourly forecast");
        if (outing.isEmpty()) outing = today;
        if (outingRain.isEmpty()) outingRain = outing;

        double feelsMin = min(feels, outing, daily.getJSONArray("apparent_temperature_min").getDouble(0));
        double feelsMax = max(feels, outing, daily.getJSONArray("apparent_temperature_max").getDouble(0));
        double midpoint = (feelsMin + feelsMax) / 2;
        String clothes, outer;
        if (midpoint >= 30) { clothes = "半袖・涼しい服"; outer = "不要"; }
        else if (midpoint >= 26) { clothes = "半袖"; outer = "不要"; }
        else if (midpoint >= 23) { clothes = "半袖〜薄手長袖"; outer = feelsMin < 20 ? "薄手の羽織り" : "不要"; }
        else if (midpoint >= 20) { clothes = "長袖"; outer = feelsMin < 17 ? "薄手の羽織り" : "不要"; }
        else if (midpoint >= 16) { clothes = "長袖"; outer = "薄手アウター"; }
        else if (midpoint >= 12) { clothes = "長袖・重ね着"; outer = "ジャケット"; }
        else if (midpoint >= 8) { clothes = "暖かい服"; outer = "コート"; }
        else if (midpoint >= 5) { clothes = "しっかり防寒"; outer = "厚手コート"; }
        else { clothes = "冬の防寒着"; outer = "冬用アウター"; }
        double maxWind = max(wind, outing, 0);
        boolean windy = maxWind >= 25 || max(gust, outing, 0) >= 40;
        if (windy && !outer.equals("冬用アウター")) {
            String[] order = {"不要", "薄手の羽織り", "薄手アウター", "ジャケット", "コート", "厚手コート", "冬用アウター"};
            for (int i = 0; i < order.length - 1; i++) if (outer.equals(order[i])) { outer = order[i + 1]; break; }
        }
        boolean outerNeeded = !outer.equals("不要");
        double maxProb = max(probability, outingRain, daily.getJSONArray("precipitation_probability_max").getDouble(0));
        double maxPrecip = max(precipitation, outingRain, 0);
        int rainyHours = 0;
        for (int i : outingRain) if (precipitation.getDouble(i) >= .1) rainyHours++;
        boolean rainCode = false, snowCode = false;
        for (int i : outing) {
            rainCode |= isRain(codes.getInt(i));
            snowCode |= isSnow(codes.getInt(i));
        }
        String umbrella = "不要";
        if (snowCode && maxPrecip >= 1 || rainyHours >= 3 && maxProb >= 60 && maxPrecip < 2
                || maxPrecip >= 3 || maxProb >= 80 && maxPrecip >= 1 || rainCode && maxPrecip >= 2)
            umbrella = "普通の傘";
        else if (maxProb >= 30 || maxPrecip >= .1 || rainCode) umbrella = "折りたたみ傘";

        String tempVoice = midpoint >= 29 ? "日中はかなり暑く感じそうです"
                : midpoint >= 25 ? "日中は少し暑く感じそうです"
                : midpoint >= 20 ? "気温はおおむね過ごしやすそうです"
                : midpoint >= 15 ? "少し涼しく感じる時間がありそうです"
                : midpoint >= 10 ? "肌寒く感じそうです" : "かなり寒く感じそうです";
        int dailyCode = daily.getJSONArray("weather_code").getInt(0);
        String weather = weatherLabel(dailyCode);
        int high = (int) Math.round(daily.getJSONArray("temperature_2m_max").getDouble(0));
        int low = (int) Math.round(daily.getJSONArray("temperature_2m_min").getDouble(0));

        List<Period> periods = new ArrayList<>();
        for (int i : today) {
            int h = hour(times.getString(i));
            double amount = precipitation.getDouble(i);
            int code = codes.getInt(i);
            if (amount >= .1 && h > 0) periods.add(new Period(h - 1, h));
            else if (isRain(code) || isSnow(code)) periods.add(new Period(h, Math.min(24, h + 1)));
        }
        periods.sort(Comparator.comparingInt(p -> p.start));
        List<Period> merged = new ArrayList<>();
        for (Period p : periods) {
            if (merged.isEmpty() || p.start > merged.get(merged.size() - 1).end) merged.add(p);
            else merged.get(merged.size() - 1).end = Math.max(merged.get(merged.size() - 1).end, p.end);
        }
        double now = currentTime.startsWith(date) ? hour(currentTime) + minute(currentTime) / 60.0 : 0;
        List<Period> future = new ArrayList<>();
        for (Period p : merged) if (p.end > now + .01) future.add(p);
        String rainText, rainVoice;
        if (future.isEmpty()) {
            double futureProb = 0;
            for (int i : today) if (hour(times.getString(i)) >= Math.floor(now))
                futureProb = Math.max(futureProb, probability.getDouble(i));
            rainText = futureProb >= 30 ? "雨の可能性はありますが、降り始める時間はまだはっきりしていません。"
                    : "このあと、まとまった雨の予報はありません。";
        } else {
            rainText = "雨は" + periodText(future.get(0), now);
            if (future.size() > 1) rainText += "、その後" + periodText(future.get(1), now);
            rainText += "の見込みです。";
            if (future.size() > 2) rainText += " その後も雨の時間帯があります。";
        }
        rainVoice = rainText.replaceFirst("。$", "");

        // Same future-only sudden rain checks as the web app.
        List<Double> futureProbs = new ArrayList<>(), futureAmounts = new ArrayList<>();
        boolean thunder = false, shower = false;
        for (int i : outing) if (hour(times.getString(i)) >= Math.floor(now)) {
            int code = codes.getInt(i);
            thunder |= code == 95 || code == 96 || code == 97 || code == 99;
            shower |= code == 80 || code == 81 || code == 82;
        }
        for (int i : outingRain) if (hour(times.getString(i)) > now) {
            futureProbs.add(probability.getDouble(i));
            futureAmounts.add(precipitation.getDouble(i));
        }
        double maxFuture = 0, minFuture = Double.POSITIVE_INFINITY, jump = 0;
        boolean isolated = false;
        for (int i = 0; i < futureProbs.size(); i++) {
            double p = futureProbs.get(i);
            maxFuture = Math.max(maxFuture, p);
            minFuture = Math.min(minFuture, p);
            if (i > 0) jump = Math.max(jump, Math.abs(p - futureProbs.get(i - 1)));
            if (futureAmounts.get(i) >= .1
                    && (i == 0 || futureAmounts.get(i - 1) < .1)
                    && (i == futureAmounts.size() - 1 || futureAmounts.get(i + 1) < .1)) isolated = true;
        }
        String suddenText = "", suddenVoice = "";
        if (thunder) {
            suddenText = "雷を伴う急な雨の予報があります。空模様が急に変わる可能性があるため、外出時は雨具を持っておくと安心です。";
            suddenVoice = "雷を伴う急な雨の予報があります。空模様が急に変わる可能性があるため、雨具を持っておくと安心です";
        } else if (shower) {
            suddenText = "にわか雨の予報があります。晴れていても急に降る可能性があるため、外出時は雨具を用意しておくと安心です。";
            suddenVoice = "にわか雨の予報があります。晴れていても急に降る可能性があるため、雨具を用意しておくと安心です";
        } else if (maxFuture >= 40 && (maxFuture - minFuture >= 35 || jump >= 30 || isolated)) {
            suddenText = "時間帯によって雨の可能性が大きく変わる予報です。急な雨に備えて、外出時は雨具を用意しておくと安心です。";
            suddenVoice = "今日は天気が変わりやすい予報です。急な雨に備えて、雨具を用意しておくと安心です";
        }

        StringBuilder display = new StringBuilder(place + "は今日は" + weather + "。最高" + high
                + "℃、最低" + low + "℃の予報です。\n" + tempVoice + "。\n服装は" + clothes
                + "。アウターは" + (outerNeeded ? "必要（" + outer + "）" : "不要") + "です。\n");
        if (umbrella.equals("普通の傘")) display.append("普通の傘を持っていくのがおすすめです。").append(rainText);
        else if (umbrella.equals("折りたたみ傘")) display.append("折りたたみ傘があると安心です。").append(rainText);
        else display.append(rainText);
        if (!suddenText.isEmpty()) display.append('\n').append(suddenText);
        double windMs = maxWind / 3.6;
        if (windMs >= 10) display.append('\n').append("最大風速は約").append(oneDecimal(windMs)).append("m/s。風がかなり強くなる可能性があります。");
        else if (windMs >= 7) display.append('\n').append("最大風速は約").append(oneDecimal(windMs)).append("m/s。風が強めなので注意してください。");
        String weekly = weekly(daily);
        display.append("\n\nこの先1週間：").append(weekly);
        if (fromCache) display.append("\n\n※ 保存済みの予報です。");

        String umbrellaVoice = umbrella.equals("普通の傘") ? "雨に備えて、普通の傘がおすすめです。" + rainVoice + "。"
                : umbrella.equals("折りたたみ傘") ? "折りたたみ傘を持っていくと安心です。" + rainVoice + "。"
                : "傘は必要ありません。";
        StringBuilder spoken = new StringBuilder("おはようございます。" + place.replace('・', '、')
                + "の今日の天気をお伝えします。今日は" + weather + "。最高気温は" + high
                + "度、最低気温は" + low + "度の予報です。" + tempVoice + "。服装は" + clothes
                + "がおすすめです。");
        spoken.append(outerNeeded ? "今日はアウターが必要です。" + outer + "がちょうどよさそうです。" : "今日はアウターは必要ありません。");
        if (umbrella.equals("不要")) spoken.append(rainVoice).append('。');
        // Rainfall peak is a separate sentence only when measurable rain is forecast after now.
        double peak = 0; int peakEnd = -1;
        for (int i : today) {
            int h = hour(times.getString(i));
            if (h <= now) continue;
            double amount = precipitation.getDouble(i);
            if (peakEnd < 0 || amount > peak) { peak = amount; peakEnd = h; }
        }
        if (peak >= .1) spoken.append(Math.max(0, peakEnd - 1)).append("時から").append(peakEnd)
                .append("時の1時間雨量は、最大").append(oneDecimal(peak)).append("ミリの予報です。");
        if (!suddenVoice.isEmpty()) spoken.append(suddenVoice).append('。');
        spoken.append(umbrellaVoice);
        if (windMs >= 10) spoken.append("今日は最大風速が約").append(oneDecimal(windMs)).append("メートル毎秒の予報で、風がかなり強めです。傘があおられたり、歩きにくくなることがあるので注意してください。");
        else if (windMs >= 7) spoken.append("今日は最大風速が約").append(oneDecimal(windMs)).append("メートル毎秒の予報で、風が強めです。傘や帽子があおられないよう注意してください。");
        spoken.append(weekly);
        if (fromCache) spoken.append("なお、通信できないため、保存してある予報を読み上げています。");
        spoken.append("以上、今日の天気でした。気をつけていってらっしゃい。");
        return new ForecastSummary(display.toString(), spoken.toString());
    }

    private static final class Period {
        final int start; int end;
        Period(int start, int end) { this.start = start; this.end = end; }
    }
    private static String periodText(Period p, double now) {
        if (now >= p.start && now < p.end) return "現在降っていて、" + hourText(p.end) + "にやむ見込み";
        return hourText(p.start) + "から" + hourText(p.end) + "まで";
    }
    private static String hourText(int h) { return h >= 24 ? "日付が変わるころ" : h + "時ごろ"; }
    private static int hour(String time) { return Integer.parseInt(time.substring(11, 13)); }
    private static int minute(String time) { return Integer.parseInt(time.substring(14, 16)); }
    private static double min(JSONArray array, List<Integer> indexes, double fallback) throws Exception {
        if (indexes.isEmpty()) return fallback;
        double result = Double.POSITIVE_INFINITY;
        for (int i : indexes) result = Math.min(result, array.getDouble(i));
        return result;
    }
    private static double max(JSONArray array, List<Integer> indexes, double fallback) throws Exception {
        if (indexes.isEmpty()) return fallback;
        double result = Double.NEGATIVE_INFINITY;
        for (int i : indexes) result = Math.max(result, array.getDouble(i));
        return result;
    }
    private static boolean isRain(int c) {
        return c >= 51 && c <= 67 || c >= 80 && c <= 82 || c >= 95;
    }
    private static boolean isSnow(int c) { return c >= 71 && c <= 77 || c == 85 || c == 86; }
    private static String oneDecimal(double n) { return String.format(Locale.US, "%.1f", Math.round(n * 10) / 10.0); }
    private static String weekly(JSONObject daily) throws Exception {
        JSONArray dates = daily.getJSONArray("time"), codes = daily.getJSONArray("weather_code");
        JSONArray highs = daily.getJSONArray("temperature_2m_max");
        JSONArray probabilities = daily.getJSONArray("precipitation_probability_max");
        String[] days = {"日曜", "月曜", "火曜", "水曜", "木曜", "金曜", "土曜"};
        List<String> rainDays = new ArrayList<>();
        StringBuilder result = new StringBuilder("明日からは、");
        int minHigh = Integer.MAX_VALUE, maxHigh = Integer.MIN_VALUE;
        for (int i = 1; i <= 6; i++) {
            String day = days[LocalDate.parse(dates.getString(i)).getDayOfWeek().getValue() % 7];
            if (i <= 3) {
                if (i > 1) result.append('、');
                result.append(day).append("は").append(weatherLabel(codes.getInt(i)));
            }
            int high = (int) Math.round(highs.getDouble(i));
            minHigh = Math.min(minHigh, high);
            maxHigh = Math.max(maxHigh, high);
            if (probabilities.getDouble(i) >= 40) rainDays.add(day);
        }
        result.append("の予報です。最高気温は").append(minHigh).append('〜').append(maxHigh).append("度くらい。");
        if (rainDays.isEmpty()) result.append("大きな雨の予報は少なめです。");
        else {
            result.append("雨に備えたい日は");
            for (int i = 0; i < Math.min(3, rainDays.size()); i++) {
                if (i > 0) result.append('・');
                result.append(rainDays.get(i));
            }
            if (rainDays.size() > 3) result.append("など");
            result.append("です。");
        }
        return result.toString();
    }
    private static String weatherLabel(int c) {
        switch (c) {
            case 0: return "快晴"; case 1: return "晴れ"; case 2: return "晴れ時々曇り"; case 3: return "曇り";
            case 45: return "霧"; case 48: return "着氷性の霧";
            case 51: return "弱い霧雨"; case 53: return "霧雨"; case 55: return "強い霧雨";
            case 56: return "弱い着氷性霧雨"; case 57: return "強い着氷性霧雨";
            case 61: return "弱い雨"; case 63: return "雨"; case 65: return "強い雨";
            case 66: return "弱い着氷性の雨"; case 67: return "強い着氷性の雨";
            case 71: return "弱い雪"; case 73: return "雪"; case 75: return "強い雪"; case 77: return "雪あられ";
            case 80: return "弱いにわか雨"; case 81: return "にわか雨"; case 82: return "激しいにわか雨";
            case 85: return "弱いにわか雪"; case 86: return "強いにわか雪";
            case 95: return "雷雨"; case 96: return "雷雨・ひょう"; case 97: return "激しい雷雨";
            case 99: return "激しい雷雨・ひょう"; default: return "天気情報";
        }
    }
}
