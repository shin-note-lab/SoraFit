package jp.shinnote.sorafit.widget;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class WeatherData {
    final String icon, description, updated;
    final int temperature, high, low, rain, tomorrowHigh, tomorrowLow, tomorrowRain;
    final String tomorrowIcon;

    private WeatherData(JSONObject json) throws Exception {
        JSONObject current = json.getJSONObject("current");
        JSONObject daily = json.getJSONObject("daily");
        int code = current.getInt("weather_code");
        icon = symbol(code);
        description = label(code);
        temperature = (int) Math.round(current.getDouble("temperature_2m"));
        high = (int) Math.round(daily.getJSONArray("temperature_2m_max").getDouble(0));
        low = (int) Math.round(daily.getJSONArray("temperature_2m_min").getDouble(0));
        rain = daily.getJSONArray("precipitation_probability_max").getInt(0);
        JSONArray codes = daily.getJSONArray("weather_code");
        tomorrowIcon = codes.length() > 1 ? symbol(codes.getInt(1)) : "—";
        tomorrowHigh = daily.getJSONArray("temperature_2m_max").length() > 1
                ? (int) Math.round(daily.getJSONArray("temperature_2m_max").getDouble(1)) : 0;
        tomorrowLow = daily.getJSONArray("temperature_2m_min").length() > 1
                ? (int) Math.round(daily.getJSONArray("temperature_2m_min").getDouble(1)) : 0;
        tomorrowRain = daily.getJSONArray("precipitation_probability_max").length() > 1
                ? daily.getJSONArray("precipitation_probability_max").getInt(1) : 0;
        updated = new SimpleDateFormat("H:mm", Locale.JAPAN).format(new Date(json.optLong("_fetchedAt", 0)));
    }

    static WeatherData fromJson(String saved) {
        try { return saved == null ? null : new WeatherData(new JSONObject(saved)); }
        catch (Exception ignored) { return null; }
    }

    static String forecastUrl(double lat, double lon) {
        return "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
                + "&current=temperature_2m,weather_code"
                + "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
                + "&timezone=Asia%2FTokyo&forecast_days=2";
    }

    static String readJson(String url) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setConnectTimeout(7000);
        connection.setReadTimeout(7000);
        connection.setRequestProperty("Accept", "application/json");
        try {
            if (connection.getResponseCode() != 200) throw new IllegalStateException("HTTP " + connection.getResponseCode());
            try (InputStream stream = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                StringBuilder result = new StringBuilder();
                char[] buffer = new char[4096];
                int n;
                while ((n = reader.read(buffer)) != -1) {
                    result.append(buffer, 0, n);
                    if (result.length() > 200_000) throw new IllegalStateException("Response too large");
                }
                return result.toString();
            }
        } finally {
            connection.disconnect();
        }
    }

    static String symbol(int code) {
        if (code == 0) return "☀";
        if (code <= 3) return "⛅";
        if (code == 45 || code == 48) return "☁";
        if (code >= 71 && code <= 77 || code >= 85 && code <= 86) return "❄";
        if (code >= 95) return "⛈";
        return "☂";
    }

    static String label(int code) {
        if (code == 0) return "晴れ";
        if (code <= 3) return "くもり";
        if (code == 45 || code == 48) return "霧";
        if (code >= 71 && code <= 77 || code >= 85 && code <= 86) return "雪";
        if (code >= 95) return "雷雨";
        return "雨";
    }
}
