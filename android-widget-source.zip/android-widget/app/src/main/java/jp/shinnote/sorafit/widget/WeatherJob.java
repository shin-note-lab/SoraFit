package jp.shinnote.sorafit.widget;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.appwidget.AppWidgetManager;
import android.content.SharedPreferences;

import org.json.JSONObject;

public final class WeatherJob extends JobService {
    @Override public boolean onStartJob(JobParameters params) {
        int id = params.getJobId() - 200_000;
        new Thread(() -> {
            boolean failed = false;
            try {
                SharedPreferences settings = WeatherWidget.prefs(this);
                if (settings.contains(id + ".lat")) {
                    double lat = Double.longBitsToDouble(settings.getLong(id + ".lat", 0));
                    double lon = Double.longBitsToDouble(settings.getLong(id + ".lon", 0));
                    JSONObject data = new JSONObject(WeatherData.readJson(WeatherData.forecastUrl(lat, lon)));
                    data.put("_fetchedAt", System.currentTimeMillis());
                    if (WeatherData.fromJson(data.toString()) == null) throw new IllegalStateException("Invalid forecast");
                    settings.edit().putString(id + ".weather", data.toString()).apply();
                }
            } catch (Exception error) {
                failed = true;
            }
            if (WeatherWidget.prefs(this).contains(id + ".lat")) WeatherWidget.render(this, id, failed);
            jobFinished(params, false);
        }, "sorafit-forecast").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) { return true; }
}
