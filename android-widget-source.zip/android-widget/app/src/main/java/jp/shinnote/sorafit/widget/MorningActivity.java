package jp.shinnote.sorafit.widget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;

/** A visible activity keeps the speech session alive after the widget tap. */
public final class MorningActivity extends Activity {
    private TextView summaryView;
    private Button playButton;
    private TextToSpeech speech;
    private boolean speechReady;
    private boolean started;
    private String spokenText;
    private int widgetId;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        widgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(19, 39, 64));
        TextView title = new TextView(this);
        title.setText("🔊 朝の概要");
        title.setTextSize(24);
        title.setTextColor(Color.WHITE);
        root.addView(title);

        summaryView = new TextView(this);
        summaryView.setText("予報を読み込んでいます…");
        summaryView.setTextSize(17);
        summaryView.setTextColor(Color.WHITE);
        summaryView.setLineSpacing(dp(6), 1);
        summaryView.setPadding(0, dp(26), 0, dp(20));
        root.addView(summaryView);

        playButton = new Button(this);
        playButton.setText("もう一度聞く");
        playButton.setEnabled(false);
        playButton.setOnClickListener(v -> {
            if (speechReady && spokenText != null) {
                speech.stop();
                speech.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "sorafit-morning");
            }
        });
        root.addView(playButton);

        Button stopButton = new Button(this);
        stopButton.setText("読み上げを停止");
        stopButton.setOnClickListener(v -> { if (speech != null) speech.stop(); });
        root.addView(stopButton);
        setContentView(root);

        SharedPreferences settings = WeatherWidget.prefs(this);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID || !settings.contains(widgetId + ".lat")) {
            summaryView.setText("先にウィジェットの表示地域を選んでください。");
            Button configure = new Button(this);
            configure.setText("地域を設定");
            configure.setOnClickListener(v -> {
                startActivity(new Intent(this, MainActivity.class)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
                finish();
            });
            root.addView(configure);
            return;
        }

        speech = new TextToSpeech(this, status -> summaryView.post(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (status == TextToSpeech.SUCCESS && speech != null
                    && speech.setLanguage(Locale.JAPAN) >= TextToSpeech.LANG_AVAILABLE) {
                speechReady = true;
                playButton.setEnabled(spokenText != null);
                startSpeaking();
            } else {
                summaryView.append("\n\n音声読み上げを利用できません。端末の日本語音声を確認してください。");
            }
        }));
        loadForecast(settings);
    }

    private void loadForecast(SharedPreferences settings) {
        String saved = settings.getString(widgetId + ".weather", null);
        WeatherData cached = WeatherData.fromJson(saved);
        long fetchedAt = 0;
        try { if (saved != null) fetchedAt = new JSONObject(saved).optLong("_fetchedAt", 0); }
        catch (Exception ignored) { }
        if (cached != null && System.currentTimeMillis() - fetchedAt < 60 * 60 * 1000L) {
            showForecast(settings, cached, false);
            return;
        }
        new Thread(() -> {
            WeatherData fresh = null;
            try {
                double lat = Double.longBitsToDouble(settings.getLong(widgetId + ".lat", 0));
                double lon = Double.longBitsToDouble(settings.getLong(widgetId + ".lon", 0));
                JSONObject json = new JSONObject(WeatherData.readJson(WeatherData.forecastUrl(lat, lon)));
                json.put("_fetchedAt", System.currentTimeMillis());
                fresh = WeatherData.fromJson(json.toString());
                if (fresh != null) settings.edit().putString(widgetId + ".weather", json.toString()).apply();
            } catch (Exception ignored) { }
            WeatherData result = fresh != null ? fresh : cached;
            boolean offline = fresh == null;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (result == null) summaryView.setText("予報を取得できませんでした。通信を確認して開き直してください。");
                else {
                    showForecast(settings, result, offline);
                    if (!offline) {
                        try { WeatherWidget.render(this, widgetId, false); }
                        catch (RuntimeException ignored) { }
                    }
                }
            });
        }, "sorafit-morning").start();
    }

    private void showForecast(SharedPreferences settings, WeatherData data, boolean offline) {
        String city = settings.getString(widgetId + ".name", "設定した地域").replace('・', '、');
        String umbrella = data.rain >= 60 ? "傘を持ってお出かけください。"
                : data.rain >= 30 ? "折りたたみ傘があると安心です。" : "雨の可能性は低めです。";
        String clothes = data.high < 10 ? "暖かい上着を用意してください。"
                : data.high < 18 ? "羽織るものがあると安心です。"
                : data.high >= 28 ? "暑さに気をつけてください。" : "過ごしやすい気温になりそうです。";
        spokenText = "朝の概要です。" + city + "の今日は" + data.description + "。現在" + data.temperature
                + "度、最高" + data.high + "度、最低" + data.low + "度、降水確率は" + data.rain
                + "パーセントです。" + umbrella + clothes
                + (offline ? "通信できないため、保存済みの予報を読み上げています。" : "");
        summaryView.setText(city + "の今日の天気：" + data.description
                + "\n現在 " + data.temperature + "℃ ／ 最高 " + data.high + "℃ ／ 最低 " + data.low
                + "℃\n降水確率 " + data.rain + "%\n" + umbrella + "\n" + clothes
                + (offline ? "\n\n※ 保存済みの予報です。" : ""));
        playButton.setEnabled(speechReady);
        startSpeaking();
    }

    private void startSpeaking() {
        if (!started && speechReady && speech != null && spokenText != null) {
            started = true;
            speech.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "sorafit-morning");
        }
    }

    @Override protected void onDestroy() {
        if (speech != null) { speech.stop(); speech.shutdown(); }
        super.onDestroy();
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
