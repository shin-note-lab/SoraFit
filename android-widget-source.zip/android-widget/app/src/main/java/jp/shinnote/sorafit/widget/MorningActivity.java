package jp.shinnote.sorafit.widget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;
import java.time.LocalDate;
import java.time.ZoneId;

/** A visible activity keeps the speech session alive after the widget tap. */
public final class MorningActivity extends Activity {
    private TextView summaryView;
    private Button playButton;
    private TextToSpeech speech;
    private boolean speechReady;
    private boolean started;
    private String spokenText;
    private int widgetId;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        widgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(19, 39, 64));
        TextView title = new TextView(this);
        title.setText("🔊 Weather Brief");
        title.setTextSize(24);
        title.setTextColor(Color.WHITE);
        root.addView(title);

        summaryView = new TextView(this);
        summaryView.setText("予報を読み込んでいます…");
        summaryView.setTextSize(17);
        summaryView.setTextColor(Color.WHITE);
        summaryView.setLineSpacing(dp(6), 1);
        summaryView.setPadding(0, dp(26), 0, dp(20));
        root.addView(summaryView);

        playButton = new Button(this);
        playButton.setText("もう一度聞く");
        playButton.setEnabled(false);
        playButton.setOnClickListener(v -> {
            if (speechReady && spokenText != null) {
                speech.stop();
                speech.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "sorafit-morning");
            }
        });
        root.addView(playButton);

        Button stopButton = new Button(this);
        stopButton.setText("読み上げを停止");
        stopButton.setOnClickListener(v -> { if (speech != null) speech.stop(); });
        root.addView(stopButton);
        setContentView(root);

        SharedPreferences settings = WeatherWidget.prefs(this);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID || !settings.contains(widgetId + ".lat")) {
            summaryView.setText("先にウィジェットの表示地域を選んでください。");
            Button configure = new Button(this);
            configure.setText("地域を設定");
            configure.setOnClickListener(v -> {
                startActivity(new Intent(this, MainActivity.class)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
                finish();
            });
            root.addView(configure);
            return;
        }

        speech = new TextToSpeech(this, status -> summaryView.post(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (status == TextToSpeech.SUCCESS && speech != null
                    && speech.setLanguage(Locale.JAPAN) >= TextToSpeech.LANG_AVAILABLE) {
                speechReady = true;
                playButton.setEnabled(spokenText != null);
                startSpeaking();
            } else {
                summaryView.append("\n\n音声読み上げを利用できません。端末の日本語音声を確認してください。");
            }
        }));
        loadForecast(settings);
    }

    private void loadForecast(SharedPreferences settings) {
        String saved = settings.getString(widgetId + ".weather", null);
        String place = settings.getString(widgetId + ".name", "設定した地域");
        ForecastSummary cached = null;
        try { if (saved != null) cached = ForecastSummary.fromJson(saved, place, false); }
        catch (Exception ignored) { }
        long fetchedAt = 0;
        try { if (saved != null) fetchedAt = new JSONObject(saved).optLong("_fetchedAt", 0); }
        catch (Exception ignored) { }
        String today = LocalDate.now(ZoneId.of("Asia/Tokyo")).toString();
        boolean currentDay = false;
        try { currentDay = saved != null && today.equals(new JSONObject(saved).getJSONObject("daily").getJSONArray("time").getString(0)); }
        catch (Exception ignored) { }
        if (cached != null && currentDay && System.currentTimeMillis() - fetchedAt < 60 * 60 * 1000L) {
            showForecast(cached);
            return;
        }
        new Thread(() -> {
            ForecastSummary fresh = null;
            try {
                double lat = Double.longBitsToDouble(settings.getLong(widgetId + ".lat", 0));
                double lon = Double.longBitsToDouble(settings.getLong(widgetId + ".lon", 0));
                JSONObject json = new JSONObject(WeatherData.readJson(WeatherData.forecastUrl(lat, lon)));
                json.put("_fetchedAt", System.currentTimeMillis());
                fresh = ForecastSummary.fromJson(json.toString(), place, false);
                settings.edit().putString(widgetId + ".weather", json.toString()).apply();
            } catch (Exception ignored) { }
            ForecastSummary result = fresh;
            if (result == null && saved != null) {
                try { result = ForecastSummary.fromJson(saved, place, true); }
                catch (Exception ignored) { }
            }
            boolean offline = fresh == null;
            ForecastSummary summary = result;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (summary == null) summaryView.setText("予報を取得できませんでした。通信を確認して開き直してください。");
                else {
                    showForecast(summary);
                    if (!offline) {
                        try { WeatherWidget.render(this, widgetId, false); }
                        catch (RuntimeException ignored) { }
                    }
                }
            });
        }, "sorafit-morning").start();
    }

    private void showForecast(ForecastSummary summary) {
        spokenText = summary.voice;
        summaryView.setText(summary.text);
        playButton.setEnabled(speechReady);
        startSpeaking();
    }

    private void startSpeaking() {
        if (!started && speechReady && speech != null && spokenText != null) {
            started = true;
            speech.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "sorafit-morning");
        }
    }

    @Override protected void onDestroy() {
        if (speech != null) { speech.stop(); speech.shutdown(); }
        super.onDestroy();
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
